#ifndef SDCARD_H
#define SDCARD_H
#include <Arduino.h>
#include <FS.h>
#include <SD.h>
#endif
