#ifndef IMGVIEWER_H
#define IMGVIEWER_H
#include <TFT_eSPI.h>
#include <SD.h>
extern TFT_eSPI tft;
extern std::vector<String> images;

void showImage(int idx){
  if(idx < 0 || idx >= (int)images.size()) return;
  String path = String("/sdcard/Images/") + images[idx];
  File f = SD.open(path);
  if(!f){
    tft.fillScreen(TFT_BLACK);
    tft.setCursor(10,100);
    tft.println("Failed to open image");
    return;
  }
  tft.fillScreen(TFT_BLACK);
  // try TFT_eSPI jpeg from file
  if(tft.drawJpgFile(SD, path.c_str(), 0, 0) == 0){
    // fallback: show filename
    tft.setCursor(10,100);
    tft.println(images[idx]);
  }
  f.close();
}
#endif
