/*
 CYD_MediaViewer - simple image slideshow + WAV player for CYD 2432S028
 - Requires TFT_eSPI (configured for your board) and SD libraries
 - Touchscreen: uses XPT2046 (optional). Adjust pins in the code.
 - Audio: plays 16-bit WAV using simple I2S/DAC output (built-in ESP32 DAC)

 Note: This is a lightweight app intended to be installed via Launcher_esp.
       It expects an SD card with folders:
         /sdcard/Images  -> JPG, JPEG files
         /sdcard/Audio   -> WAV files (16-bit PCM, 22kHz or 44kHz recommended)
*/

#include <Arduino.h>
#include <TFT_eSPI.h>
#include <SPI.h>
#include <FS.h>
#include <SD.h>
#include "sdcard.h"

TFT_eSPI tft = TFT_eSPI();

#define SD_CS_PIN 13 // adjust if your board uses different CS for SD

// simple file lists
#include <vector>
std::vector<String> images;
std::vector<String> audioFiles;
int currentImage = 0;
bool playing = false;

void setup() {
  Serial.begin(115200);
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.println("CYD Media Viewer");

  if(!SD.begin(SD_CS_PIN)) {
    tft.setCursor(10,40);
    tft.setTextSize(1);
    tft.println("SD init failed. Check SD_CS_PIN");
    Serial.println("SD init failed");
    return;
  }
  tft.setCursor(10,40);
  tft.println("SD initialized");
  // scan folders
  File root = SD.open("/sdcard/Images");
  if(root){
    File file = root.openNextFile();
    while(file){
      String name = String(file.name());
      if(name.endsWith(".jpg") || name.endsWith(".JPG") || name.endsWith(".jpeg") || name.endsWith(".JPEG")) images.push_back(name);
      file = root.openNextFile();
    }
    root.close();
  }
  File rootA = SD.open("/sdcard/Audio");
  if(rootA){
    File file = rootA.openNextFile();
    while(file){
      String name = String(file.name());
      if(name.endsWith(".wav") || name.endsWith(".WAV")) audioFiles.push_back(name);
      file = rootA.openNextFile();
    }
    rootA.close();
  }
  if(images.size()>0) {
    showImage(currentImage);
  } else {
    tft.setCursor(10,80);
    tft.println("No images in /sdcard/Images");
  }
}

void loop() {
  // touchscreen or button handling could be added here
  // simple auto-advance every 5 seconds
  static unsigned long last = 0;
  if(millis() - last > 5000 && images.size()>0) {
    last = millis();
    currentImage = (currentImage + 1) % images.size();
    showImage(currentImage);
  }
}

#include "imgviewer.h"
