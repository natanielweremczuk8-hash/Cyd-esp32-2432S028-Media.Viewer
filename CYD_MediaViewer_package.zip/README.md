CYD_MediaViewer - build-ready PlatformIO project + GitHub Actions
=================================================================

What this is
------------
A ready-to-upload PlatformIO project that builds a Launcher_esp-compatible firmware binary for CYD 2432S028.
I included two build environments (4MB and 8/16MB). The project displays JPG images from /sdcard/Images and can list WAV audio files in /sdcard/Audio.

Why GitHub Actions?
-------------------
You said you use iOS and cannot compile locally. GitHub Actions builds the firmware in the cloud when you push this repo to GitHub.
From your iPhone you can:
  1) Create a new GitHub repository (via GitHub app or website)
  2) Upload the files from this package (there is an upload button in the GitHub mobile UI)
  3) Go to the Actions tab and run the build workflow (or it will run automatically on push)
  4) Download the produced firmware binary (.bin) artifact to your iPhone and save it to Files
  5) Copy that .bin to your microSD (use an adapter) or use a Wi-Fi file transfer app to copy to SD

Files included
--------------
- platformio.ini           (two build envs: esp32_4mb and esp32_8mb)
- src/main.cpp             (main application)
- src/imgviewer.h          (simple jpg viewer using TFT_eSPI)
- src/sdcard.h
- .github/workflows/build.yml  (GitHub Actions to build and upload artifact)

Choosing the correct build
--------------------------
You must choose the correct env in the workflow for your flash size:
- If your device has 4MB flash choose env: esp32_4mb
- If your device has 8MB or more choose env: esp32_8mb
If you choose wrong, the produced firmware might not boot. Check Launcher_esp -> Device Info to confirm flash size before building.

How to install on the device with Launcher_esp
----------------------------------------------
1) Download the firmware .bin from the GitHub Actions artifacts to your iPhone.
2) Copy the .bin into the root of a FAT32-formatted microSD (name it CYD_MediaViewer.bin).
3) Insert the SD into the device and boot Launcher_esp.
4) In Launcher_esp go to SD -> Install -> choose the .bin and install it to an app slot.
5) Reboot the device; the app should appear in Launcher_esp menu.

Limitations & notes
-------------------
- This app uses TFT_eSPI.drawJpgFile which may require configuring TFT_eSPI User_Setup.h for your specific CYD board's pins.
- Video playback is not included (ESP32 can't easily decode H.264/MP4). A common workaround is MJPEG (frame-by-frame JPGs) — you can convert a video into a sequence of JPG frames and place them in /sdcard/Images; the app will play them as a slideshow (tweak timing in main.cpp).
- Audio playback for WAV files is not implemented here due to wide hardware variations; I can add a simple WAV player using the ESP32 I2S DAC in a follow-up if you want.
- If you want me to add MJPEG-style fast playback and WAV player, I'll add that to the source before you push.

